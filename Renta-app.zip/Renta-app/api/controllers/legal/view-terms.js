module.exports = {


  friendlyName: 'View terms',


  description: 'Display "Legal terms" page.',


  exits: {

    success: {
      viewTemplatePath: 'pages/legal/terms'
    }

  },


  fn: async function () {

    // All done.
    return;

  }


};
