module.exports = {
    posts: function(req, res) {
        res.send("this is posts endpoint")
    },
    create: function(req, res) {

        res.end("hello World")
    },
    delete: function(req, res) {

    }

}